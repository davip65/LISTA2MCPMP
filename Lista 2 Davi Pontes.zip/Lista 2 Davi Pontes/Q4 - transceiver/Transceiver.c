#include <p18f4520.h>


#define TXD PORTCbits.RC0 
#define RXD PORTCbits.RC1
#define umBit 54 
#define meio_bit 27
#pragma config BOREN = OFF
int controle=0;



void delay (long int tempo){

	for(;tempo!=0;tempo--); // contagem at� o tempo = 0

}

void transmite_dado(char caractere){

	int i=0;
	TXD=0;
	delay(umBit);

	while(i!=8){

		TXD=caractere;
		caractere=caractere>>1;
		delay(umBit);
		i++;	
	}
	TXD=1;
	delay(umBit);
}

char recebe_dado(){

    char caractere2=0, b[8];
    int i=0,k=7;
	while (RXD) {};

    delay(meio_bit);

    while(i<9){

        if(i>0){

            b[k]= RXD;
            k--;
            delay(umBit);
        }	
        i++;
    } 
    i=0;

    while(i<8){

		if(i<7)
        caractere2=caractere2<<1;
        caractere2=caractere2+b[i];
        i++;
    }
    return caractere2;
}

void transmissao(){

	char Caractere;
    if(RXD==0){

    	Caractere=recebe_dado();
    }
    if(controle==1){
        controle=0;
        transmite_dado(Caractere);
        transmite_dado(Caractere);
	}
}

void configuracao(){

	TXD=1;	
	TRISC=0b11111110;   
	
}

void main(void){

	configuracao();

	delay(500);
	transmite_dado('A');
	transmite_dado('A');
	transmite_dado('A');
	transmite_dado('A');
	transmite_dado('A');
	transmite_dado('A');
	transmite_dado('A');
	transmite_dado('A');

	while (1)
	{
    	transmite_dado (recebe_dado());
	}

    }


#include <p18f4520.h>

#define modo PORTAbits.RA2

int i;
unsigned char dezena=0;
unsigned char unidade=0;
unsigned char minutos_unidade=0;
unsigned char minutos_dezena=0;
unsigned char horas_unidade=0;
unsigned char horas_dezena=0;
int fim_dia = 0;


void horas_display(void){
	unsigned char BCD3;
	if(horas_unidade<10){
		BCD3 = (horas_dezena<<4|horas_unidade);
		LATB = BCD3;
		PORTEbits.RE0 = 1;
		if(fim_dia >=2 && horas_unidade >=4){ // se horas forem igual a 24, resetar tudo.
			horas_unidade = 0;
			horas_dezena = 0;
			fim_dia = 0;
		}

	}else{ // reseta caso for a hora
		horas_unidade = 0;
		BCD3 = (horas_dezena<<4|horas_unidade);
		LATB = BCD3;
		horas_dezena++; // qunado a hora. uni. resetar, aumenta um na hora. dezena.
		fim_dia++; // toda vez que resetar, vai aumentar 1. Quando aumentar pra 2, significa que ja ta na casa das 20 hrs.
	}	
}

void minutos_display(void){
	unsigned char BCD2;
	if(minutos_unidade<10){
		BCD2 = (minutos_dezena<<4|minutos_unidade);
		LATD = BCD2;
		PORTEbits.RE0 = 0;
	}else{ // reseta caso for a hora
		
		minutos_unidade = 0;
		BCD2 = (minutos_dezena<<4|minutos_unidade);
		LATD = BCD2;
		minutos_dezena++; // qunado o min. uni. resetar, aumenta um na min. dezena.
		if(minutos_dezena > 5){
			minutos_dezena = 0;
			horas_unidade++;
		}
	}
}

void taimer(void){ // conta 2 seg, necessario para o requisito do ajuste.
	unsigned short long i;
	for (i=0;i<95232;i++){} //95232
}


void ajuste_minutos(void){ // ajuste dos minutos
	
	if(PORTAbits.RA0==1){
		taimer();
		if(PORTAbits.RA0==1){
			while(PORTAbits.RA0==1){
				minutos_unidade++;
				minutos_display();
				horas_display();
				for (i=0;i<15616;i++){} // faz o ajuste dos minutos n�o ser t�o rapido.
			}
			
		}
	}

}





void ajuste_horas(void){ // ajuste das horas.
	
	if(PORTAbits.RA0==1){
		taimer();
		if(PORTAbits.RA0==1){
			while(PORTAbits.RA0==1){
				horas_unidade++;
				horas_display();
				minutos_display();
				for (i=0;i<15616;i++){} // faz o ajuste das horas n�o ser t�o rapido.
			}
			
		}
	}

}




void ajuste(void){
	if(modo == 1){ // se o modo for das horas, ajusta as horas.
		ajuste_horas();
	}else{	// se n�o, ajusta o dos minutos.
		ajuste_minutos(); 
	}
}




void contador_decimal(void){ // reseta caso necess�rio
	if(++unidade>=10){ 
		unidade=0;
		if(++dezena>=6){
			dezena=0;
			minutos_unidade++;
			
		}
	}
}

void mostra_contador(){//COME�A A CONTAR OS SEGUNDOS
	unsigned char BCD, aux;
	BCD = (dezena<<4|unidade);
	LATC = BCD;
	PORTEbits.RE0 = 0;
	ajuste(); // chama o ajuste, para caso ele esteja apertado, ele funcione
	
}

void delays(void){
	unsigned short long i;
	for (i=0;i<35616;i++){} //47616
}


main(){
	TRISC = 0b00000000;
	TRISD = 0b00000000;
	TRISB = 0b00000000;
	TRISAbits.RA0 = 1; // liga a porta RA0 entrada
	TRISAbits.RA1 = 0;
	TRISAbits.RA2 = 1; // entrada do modo
	ADCON1 = 0b00001111;
	TRISEbits.RE0 = 0;
	

	while(1){
		mostra_contador();
		delays();
		contador_decimal();
		minutos_display();
		horas_display();
	}
}
		
